import React from "react";

export default function BlankLayout({ children }) {
    return <div>{children}</div>;
}