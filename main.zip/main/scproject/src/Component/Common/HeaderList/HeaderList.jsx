import React from "react";
import "./HeaderList.scss";

export default function HeaderList({ title }) {
  return <div className="header-list">{title}</div>;
}
