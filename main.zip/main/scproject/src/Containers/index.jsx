export { default as HomePageChat } from "./Home/HomePageChat";
export { default as Login } from "./LoginRegisterComponent/Login";
export { default as Register } from "./LoginRegisterComponent/Register";
export { default as MenuStudyAI } from "../Component/LearningMenu/LearningMenu";
export { default as VolunteerSlider } from "../Component/VideoAI/VolunteerSlider" ;
export { default as Contact } from "./Contact/Contact";
export { default as Room } from "./Room/Room";
